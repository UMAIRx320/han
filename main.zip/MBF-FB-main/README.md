### Perintah Termux :
    $ apt update -y && apt upgrade -y
    $ pkg install git
    $ pkg install python3
    $ git clone https://github.com/RozhakXD/MBF-FB
    $ cd MBF-FB
    $ pip3 install -r requirements.txt
    $ python3 Run.py
### Update Script :
    $ rm -rf $HOME/MBF-FB
    $ git clone https://github.com/RozhakXD/MBF-FB
    $ cd MBF-FB
    $ python3 Run.py
